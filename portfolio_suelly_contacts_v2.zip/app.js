(function(){
  document.addEventListener('DOMContentLoaded', function(){
    document.querySelector('.page')?.classList.add('is-ready');
    const obs = new IntersectionObserver((es)=>{es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-in');}})},{threshold:.12});
    document.querySelectorAll('.reveal').forEach(el=>obs.observe(el));
    const layer=document.querySelector('.hero .parallax'); if(layer){let tx=0,ty=0,x=0,y=0;addEventListener('mousemove',e=>{const r=40,cx=innerWidth/2,cy=innerHeight/2;tx=((e.clientX-cx)/cx)*r;ty=((e.clientY-cy)/cy)*r;});(function raf(){x+=(tx-x)*.06;y+=(ty-y)*.06;layer.style.transform=`translate(${x}px,${y}px)`;requestAnimationFrame(raf);})()}
  });
  function isInternal(href){if(!href||href.startsWith('#'))return false;try{const u=new URL(href,location.href);return u.origin===location.origin}catch(e){return false}}
  addEventListener('click',e=>{const a=e.target.closest('a');if(!a)return;const h=a.getAttribute('href');if(isInternal(h)){e.preventDefault();document.body.classList.add('is-leaving');setTimeout(()=>location.href=h,180);}});
})();